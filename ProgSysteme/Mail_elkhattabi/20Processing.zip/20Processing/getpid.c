#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#define SYSTEM_PS()    system("ps -O ppid,user,stat,cls,pri,nice,rtprio")

int main(void)
{
//    pid_t monPid = getpid();
    
    printf("Je suis le processus .............. n°%d\n", getpid());
    printf("Mon processus père est le processus n°%d\n", getppid());
//    SYSTEM_PS();
    
    return 60;
}
