#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define CHECK(sts,msg) if (-1 == (sts) ) { perror (msg); exit( EXIT_FAILURE ); }

int main(int argc , char *argv [], char *envp []) {
    pid_t pidFils;
    int status;
 	char *args [] = {"sommeExecve", "1", "2", "3", "4", NULL };
   
 	printf ("Je suis le processus %d, fils du processus %d\n",	getpid () , getppid ());
   	CHECK(pidFils = fork(), "Échec de la création d'un processus fils");

    if (pidFils == 0 ) {
		printf ("Je suis le processus %d, fils du processus %d, nouvellement créée\n",	getpid () , getppid ());
 		// Executer un prg existant
	 	printf ("\nAvant lancement de execve ()\n");
		system ("ps -l");

		printf ("\nLancement de execve ()\n");
		CHECK ( execve ("./sommeExecve", args , NULL), " execve ()");

  	}
    /* On met ici la suite du code du processus père */
  
	wait(&status);
	printf("La somme est de %i\n", WEXITSTATUS(status));
	return EXIT_SUCCESS ;
}
// Tout traitemet après exec ne sera pris en compte


