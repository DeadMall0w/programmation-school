#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/wait.h>

void displayWhoami (void);

int main(void)
{
	pid_t pidFils;
	int status;

	/* Demande de création d'un processus */
	pidFils = fork ();

	displayWhoami ();
	
	if (pidFils) { // uniquement le père
		sleep(1);

#ifdef DEBUG
		system("ps -l");
#endif
		pidFils=wait(&status);
		if (WIFEXITED(status))
			printf("\tProcesus fils n° %d vient de se terminer avec la valeur de retour %d\n", pidFils, WEXITSTATUS(status)); 
#ifdef DEBUG
		system("ps -l");
		sleep(1);
#endif
 
	}
	printf ("\tFin du processus .............. n°%d\n", getpid ());

	return 10; /* Fin normale du processus père */
}

void displayWhoami (void)
{
	printf ("Je suis le processus .............. n°%d\n", getpid ());
	printf ("Mon père est le processus ......... n°%d\n", getppid ());
}

// Pour mettre en évidence l'état zombie du fils (ps -l)
