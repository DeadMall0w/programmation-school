#include <unistd.h>
#include <sched.h>
#include <stdlib.h>
#include <stdio.h>
// Contrôle des appels système
#define CHECK(sts,msg) if ((sts) == -1) {perror(msg); exit(EXIT_FAILURE); }
#define STATUS system("ps O ppid,cls,nice,pri,rtprio");

void showInfoSchedFIFO_RR (void);
void showInfoSchedCurrentProcess(void);
void modifySchedCurrentProcess (int policy, int priority);

int main (void) {
	showInfoSchedFIFO_RR() ;
	showInfoSchedCurrentProcess() ;
	STATUS;
	modifySchedCurrentProcess(SCHED_FIFO, 99);
	STATUS;
	// Mise en attente du processus pour observation
//	while (1);
	pause();
	exit(0);
}
void showInfoSchedFIFO_RR (void) {
	int highPriority, lowPriority;
	// Valeur max de la priorité avec la politique FIFO/RR
	CHECK(highPriority = sched_get_priority_max(SCHED_FIFO) ,"sched_get_priority_max");
	printf("Priorité max pour SCHED_FIFO/RR : %d\n", highPriority);
	// Valeur min de la priorité avec la politique FIFO/RR
	CHECK(lowPriority = sched_get_priority_min(SCHED_FIFO) , "sched_get_priority_min");
	printf("Priorité min pour SCHED_FIFO/RR : %d\n", lowPriority);
	return;
}
/**
* \fn void showInfoSchedProcessusCourant(void)
* \brief Affiche les informations d’ordonnancement
du processus courant
* \return pas de reéultat
*/
void showInfoSchedCurrentProcess(void) {
	int myPid = 0; // le processus courant
	int myPolicy;
	struct sched_param param;
	
	// Valeur courante de la politique
	CHECK(myPolicy = sched_getscheduler(myPid), "sched_getscheduler");
	printf("Politique d’ordonnacement du processus : %d\n", myPolicy);
	// Valeur courante de la priorité
	CHECK(sched_getparam(myPid, &param) , "sched_getparam");
	printf("Priorité actuelle du processus : %d\n", param.sched_priority);
	return;
}
/**
* \fn void modifySchedCurrentProcess (int policy, int priority)
* \brief Modifie la polique courante avec une priorité donnée
* \return pas de reéultat
*	\note	nécessite les droits d'accès
*/
void modifySchedCurrentProcess (int policy, int priority)
{
	struct sched_param param;
	param.sched_priority = priority;
	// Appliquer une nouvelle politique & priorité
	CHECK( sched_setscheduler( 0, policy, &param) , "sched_setscheduler");
}

