#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>

#define CHECK(sts, msg)	 if (-1 == (sts)) { perror(msg); exit(EXIT_FAILURE); }

int main(void)
{
    pid_t pidFils;
    
   /* Demande de création d'un processus */
    CHECK(pidFils = fork(), "Échec de la création d'un processus fils");

    if (pidFils == 0 ) {
        /*  On met ici le code spécifique du processus fils */
        exit (0); /* Fin normale du fils  */
 	}
    /* On met ici la suite du code du processus père */
  
    return  0;  /* Fin normale du processus père    */
}
