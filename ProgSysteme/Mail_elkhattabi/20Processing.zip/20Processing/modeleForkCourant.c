#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>

int main(void)
{
    pid_t pidFils;

    pidFils = fork();   /* Demande de création d'un processus */
 
    if (pidFils == -1 ) {
        /*  On met ici le code du traitement de l'erreur : cf CHECK */
        perror("Échec de la création d'un processus fils");
        exit (pidFils);
	}
    if (pidFils == 0 ) {
        /*  On met ici le code spécifique du processus fils */
        exit (0); /* Fin normale du fils  */
 	}
    /* On met ici la suite du code du processus père */
  
    return  0;  /* Fin normale du processus père    */
}
