#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>

void displayWhoami (void);

int main(void)
{
	pid_t pidFils;

	/* Demande de création d'un processus */
	pidFils = fork ();

	displayWhoami ();
//	if(pidFils !=0) 
//		printf ("J'ai créé le processus .............. n°%d\n", pidFils);
	pause();
	return 0; /* Fin normale du processus père */
}

void displayWhoami (void)
{
	printf ("Je suis le processus .............. n°%d\n", getpid ());
	printf ("Mon père est le processus ......... n°%d\n", getppid ());
}

// Montrer qu'il faut discriminer le père du fils,
// en associant un traitement spécifique au fils
