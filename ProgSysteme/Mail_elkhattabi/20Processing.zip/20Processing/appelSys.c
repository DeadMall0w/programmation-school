#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXLEN 80

int main (void)
{
    int nbLus, nbEcrits;
    char buff [MAXLEN+1];

    nbLus = read(0, buff, MAXLEN);
    nbEcrits = write (1, buff, nbLus);

    return EXIT_SUCCESS;
}
