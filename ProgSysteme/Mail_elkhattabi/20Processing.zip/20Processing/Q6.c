#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>

void displayWhoami (void);

int main(void)
{
	pid_t pidFils1 , pidFils2 , pidFils3 ;
	/* Demande de création d'un processus */
	pidFils1 = fork ();
	if(pidFils1 ==0) {
		displayWhoami ();
		/* Demande de création d'un processus */
		pidFils3 = fork ();
		if(pidFils3 ==0) {
			displayWhoami ();
			exit(0);
		}		

		exit(0);
	}		
	/* Demande de création d'un processus */
	pidFils2 = fork ();
	if(pidFils2 ==0) {
		displayWhoami ();
		exit(0);
	}		
	displayWhoami ();
	system("ps -O ppid,stat");
	pause();
	return 0; /* Fin normale du processus père */
}

void displayWhoami (void)
{
	printf ("Je suis le processus .............. n°%d\n", getpid ());
	printf ("Mon père est le processus ......... n°%d\n", getppid ());
}

// Sans discrimination, le fils se met à "forker" aussi
