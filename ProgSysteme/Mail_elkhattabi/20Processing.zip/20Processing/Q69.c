#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>

void displayWhoami (void);

int main(void)
{
	pid_t pidFils1 , pidFils2 , pidFils3 ;
	pid_t myPid = getpid();
	/* Demande de création d'un processus */
	pidFils1 = fork ();
	pidFils2 = fork ();
	pidFils3 = fork ();
	displayWhoami ();
	if (myPid == getpid()) system("ps -O ppid,stat");
	pause();
	return 0; /* Fin normale du processus père */
}

void displayWhoami (void)
{
	printf ("Je suis le processus .............. n°%d\n", getpid ());
	printf ("Mon père est le processus ......... n°%d\n", getppid ());
}

// Sans discrimination, le fils se met à "forker" aussi
