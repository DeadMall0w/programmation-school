<?php

// TODO : à compléter

$BDD_host="localhost";
$BDD_user="";
$BDD_password=""; 
$BDD_base="";

?>
