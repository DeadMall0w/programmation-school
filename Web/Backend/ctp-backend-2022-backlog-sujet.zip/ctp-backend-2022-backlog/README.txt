Mise en place préalable :
1) Créez une base de données dans phpMyAdmin et exécutez-y le fichier .SQL
2) Remplissez le fichier config.php et déplacez-le dans le dossier parent de celui-ci
    (C'est-à-dire le dossier parent de index.php et controleur.php)
    Il n'est pas nécessaire d'intégrer votre fichier config.php dans votre rendu
    Cela permet de garder la confidentialité de vos identifiants MySQL/MariaDB,
    et facilite la correction

