Note : Les fichiers JS initialement présents dans ce dossier servent uniquement à la bibliothèque Bootstrap.

