<?php

// ATTENTION : À REMPLIR ET À PLACER DANS LE DOSSIER PARENT
// 1) Remplissez les champs ci-dessous comme en TP
// 2) Déplacez ce fichier dans le dossier parent
//     (un dossier au-dessus du dossier contenant index.php et controleur.php)

$BDD_host="localhost";
$BDD_user="root";
$BDD_password="root"; 
$BDD_base="ctp_2022_backlog";

?>
