<?php

// TODO : à compléter

$BDD_host="localhost";
$BDD_user="admin";
$BDD_password="mysql"; 
$BDD_base="minutes";

?>
